import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { FaChartBar, FaBoxOpen, FaCashRegister, FaUsers, FaFileAlt, FaCog } from "react-icons/fa";
import { MdCategory, MdBrandingWatermark, MdInventory, MdReport } from "react-icons/md";
import { BsCartPlus } from "react-icons/bs";
import { AiOutlineHistory } from "react-icons/ai";
import "../style/Sidebar.css";

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [expandedMenu, setExpandedMenu] = useState(null);

  //list menu item
  const menuItems = [
    { id: "dashboard", icon: <FaChartBar />, label: "Dashboard", path: "/dashboard" },
    {
      id: "products",
      icon: <FaBoxOpen />,
      label: "Product Management",
      path: "/products",
      submenu: [
        { id: "categories", icon: <MdCategory />, label: "Categories", path: "/categories" },
        { id: "brands", icon: <MdBrandingWatermark />, label: "Brands", path: "/brands" },
        { id: "products", icon: <FaBoxOpen />, label: "Products", path: "/products" },
      ],
    },
    {
      id: "sales",
      icon: <FaCashRegister />,
      label: "Point Of Sale",
      path: "/pos",
      submenu: [
        { id: "new-sale", icon: <BsCartPlus />, label: "New Sale", path: "/sales/new" },
        { id: "sales-list", icon: <AiOutlineHistory />, label: "Sales History", path: "/sales" },
      ],
    },
    { id: "customers", icon: <FaUsers />, label: "Customer", path: "/customers" },
    {
      id: "reports",
      icon: <FaFileAlt />,
      label: "Report",
      path: "/reports",
      submenu: [
        { id: "sales-report", icon: <MdReport />, label: "Sales Report", path: "/reports/sales" },
        {
          id: "inventory-report",
          icon: <MdInventory />,
          label: "Inventory Report",
          path: "/reports/inventory",
        },
        {
          id: "customer-report",
          icon: <FaUsers />,
          label: "Customer Report",
          path: "/reports/customer",
        },
      ],
    },
    {
      id: "setting",
      icon: <FaCog />,
      label: "Setting",
      path: "/setting",
    },
  ];

  const handleNavigation = (path) => {
    navigate(path);
  };

  const toggleSubmenu = (id) => {
    setExpandedMenu(expandedMenu === id ? null : id);
  };

  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <h2>CLUBCODE POS</h2>
      </div>

      <nav className="sidebar-nav">
        {menuItems.map((item) => (
          <div key={item.id} className="nav-item-wrapper">
            <button
              className={`nav-item ${location.pathname === item.path ? "active" : ""}`}
              onClick={() => {
                if (item.submenu) {
                  toggleSubmenu(item.id);
                } else {
                  handleNavigation(item.path);
                }
              }}
            >
              <span className="nav-item-content">
                <span className="nav-icon">{item.icon}</span>
                <span className="nav-label">{item.label}</span>
              </span>
              {item.submenu && (
                <span
                  className={`submenu-toggle ${expandedMenu === item.id ? "open" : ""}`}
                >
                  ▼
                </span>
              )}
            </button>

            {item.submenu && expandedMenu === item.id && (
              <div className="submenu">
                {item.submenu.map((subitem) => (
                  <button
                    key={subitem.id}
                    className={`submenu-item ${
                      location.pathname === subitem.path ? "active" : ""
                    }`}
                    onClick={() => handleNavigation(subitem.path)}
                  >
                    <span className="nav-icon">{subitem.icon}</span>
                    <span className="nav-label">{subitem.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;
