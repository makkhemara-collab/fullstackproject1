//export const baseURL = "https://clubcode-api-pos.up.railway.app/";
export const baseURL = "http://localhost:3000/";
